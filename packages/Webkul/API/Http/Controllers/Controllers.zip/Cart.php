<?php

namespace Webkul\API\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class Cart extends Controller
{
	public function index()
	{
		$data = DB::table('cart')
		->join('cart_items', function($join){
			$join->on('cart.id', '=', 'cart_items.cart_id');
		})
		->join('product_images', function($join){
			$join->on('cart_items.product_id', '=', 'product_images.product_id');
		})
		->groupBy('product_images.product_id')
		->get();
		return response()->json([
			'cart' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);
	}
	public function get($id)
	{
		$data = DB::table('cart')
		->join('cart_items', function($join){
			$join->on('cart.id', '=', 'cart_items.cart_id');
		})
		->where('customer_id', $id)
		->get();
		return response()->json([
			'cart' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);
	}
	public function create(Request $request)
	{
		$customer_id = $request->customer_id;
		$is_gift = $request->is_gift;
		$channel_id = $request->channel_id;
		$quantity = $request->quantity;
		$price = $request->price;
		$product_id = $request->product_id;

		$data = DB::table('customers')
		->where('id', $request->customer_id)
		->first();

		$data = DB::table('cart')
		->insert([
			'customer_email' => $data->email,
			'customer_first_name' => $data->first_name,
			'customer_last_name' => $data->last_name,
			'customer_id' => $request->customer_id,
			'is_gift' => $request->is_gift,
			'channel_id' => $request->channel_id
		]);
		$id = DB::getPdo()->lastInsertId();

		$count  = count($request->product_id);
		for ($i=0; $i < $count; $i++) {
			DB::table('cart_items')
			->insert([
				'cart_id' => $id,
				'total' => $request->total[$i],
				'price' => $request->price[$i],
				'product_id' => $request->product_id[$i],
				'quantity' => $request->quantity[$i],

			]);
		}
		return response()->json([
			'cart add' => $data,
			'status_code'   => 200,
			'msg'           => 'success',
		], 201);
	}
	public function update(Request $request)
	{
		$customer_id = $request->customer_id;
		$is_gift = $request->is_gift;
		$channel_id = $request->channel_id;
		$quantity = $request->quantity;
		$price = $request->price;
		$product_id = $request->product_id;

		$data = DB::table('cart')
		->where('customer_id', $request->customer_id)
		->first();

		if ($data == TRUE) {
			$count  = count($request->product_id);
			for ($i=0; $i < $count; $i++) {
				$data2 = DB::table('cart_items')
				->where('product_id', $request->product_id[$i])
				->update([
					'quantity' => $request->quantity[$i],
				]);
			}
		}

		return response()->json([
			'cart update' => $data2,
			'status_code'   => 200,
			'msg'           => 'success',
		], 201);
	}
	public function delete(Request $request, $id)
	{
		$data = DB::table('cart_items')
		->where('cart_items.id', $request->cart_id)
		->delete();
		return response()->json([
			'User' => $id,
			'Cart' => 'Data Berhasil Dihapus',
			'status_code'   => 200,
			'msg'           => 'success',
		], 200);

	}
}
